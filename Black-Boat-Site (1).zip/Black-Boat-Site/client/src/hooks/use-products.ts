import { useQuery, useMutation } from "@tanstack/react-query";
import { api, type Product, type InsertOrder, type InsertProduct } from "@shared/routes";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Products Hook
export function useProducts() {
  return useQuery({
    queryKey: [api.products.list.path],
    queryFn: async () => {
      const res = await fetch(api.products.list.path);
      if (!res.ok) throw new Error("Failed to fetch products");
      return await res.json() as Product[];
    },
  });
}

export function useProduct(id: number) {
  return useQuery({
    queryKey: [api.products.get.path, id],
    queryFn: async () => {
      const res = await fetch(api.products.get.path.replace(':id', id.toString()));
      if (!res.ok) throw new Error("Failed to fetch product");
      return await res.json() as Product;
    },
    enabled: !!id,
  });
}

// Order Mutation
export function useCreateOrder() {
  return useMutation({
    mutationFn: async (orderData: InsertOrder) => {
      const res = await apiRequest("POST", api.orders.create.path, orderData);
      return res.json();
    },
  });
}
