import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Phone } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-screen pt-32 pb-24">
      <div className="container px-4 mx-auto max-w-5xl">
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-16 text-center">Get in Touch</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div className="space-y-10">
            <div>
              <h2 className="text-2xl font-display font-bold mb-6 text-primary">Contact Information</h2>
              <p className="text-muted-foreground mb-8">
                Have questions about our products or your order? Reach out to our team. We're here to help you look your best.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-secondary rounded-none">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Email Us</h3>
                  <p className="text-muted-foreground">salian357@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 bg-secondary rounded-none">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Call Us</h3>
                  <p className="text-muted-foreground">8317439102</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 bg-secondary rounded-none">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Visit Us</h3>
                  <p className="text-muted-foreground">
                    Bangalore
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-card border border-white/5 p-8">
            <h2 className="text-xl font-bold mb-6">Send a Message</h2>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">First Name</label>
                  <Input placeholder="shashank" className="bg-secondary/50 border-white/10 rounded-none h-12" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Second Name</label>
                  <Input placeholder="saliyan" className="bg-secondary/50 border-white/10 rounded-none h-12" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <Input placeholder="john@example.com" className="bg-secondary/50 border-white/10 rounded-none h-12" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Message</label>
                <Textarea 
                  placeholder="How can we help you?" 
                  className="bg-secondary/50 border-white/10 rounded-none min-h-[150px] resize-none" 
                />
              </div>

              <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 uppercase tracking-widest rounded-none">
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
