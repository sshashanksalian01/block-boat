import { motion } from "framer-motion";

export default function About() {
  return (
    <div className="min-h-screen pt-32 pb-24">
      <div className="container px-4 mx-auto max-w-4xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">Our Story</h1>
          <div className="w-20 h-1 bg-primary mx-auto mb-8" />
        </motion.div>

        <div className="space-y-16">
          <section className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="prose prose-invert prose-lg">
              <h2 className="text-2xl font-display font-bold mb-4 text-primary">The Beginning</h2>
              <p className="text-muted-foreground">
                Black Boat started in a small workshop with a singular mission: to restore dignity to the male grooming ritual. In a world of mass-produced plastics and harsh chemicals, we sought something different. Something real.
              </p>
              <p className="text-muted-foreground">
                Inspired by the rugged elegance of the sea and the timeless craft of traditional barbering, we formulated our first beard oil using only premium natural ingredients.
              </p>
            </div>
             <div className="aspect-[4/3] bg-secondary overflow-hidden">
                {/* Vintage barber chair or tools */}
               <img 
                 src="https://images.unsplash.com/photo-1595152772835-219674b2a8a6?q=80&w=2080&auto=format&fit=crop" 
                 alt="Our Workshop" 
                 className="w-full h-full object-cover opacity-80" 
               />
             </div>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center md:flex-row-reverse">
             <div className="aspect-[4/3] bg-secondary overflow-hidden md:order-2">
                {/* Man styling hair */}
               <img 
                 src="https://images.unsplash.com/photo-1622286342621-4bd786c2447c?q=80&w=2070&auto=format&fit=crop" 
                 alt="Man Grooming" 
                 className="w-full h-full object-cover opacity-80" 
               />
             </div>
            <div className="prose prose-invert prose-lg md:order-1">
              <h2 className="text-2xl font-display font-bold mb-4 text-primary">Our Philosophy</h2>
              <p className="text-muted-foreground">
                We believe that how a man presents himself to the world is a reflection of his self-respect. Our products are tools for the modern man to carve out his best self.
              </p>
              <p className="text-muted-foreground">
                No fillers. No shortcuts. Just pure, potent performance. Because you deserve nothing less.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
