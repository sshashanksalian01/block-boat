import { useParams } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { useCart } from "@/lib/cart-context";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingBag, Star, Shield, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetail() {
  const { id } = useParams();
  const { data: product, isLoading } = useProduct(Number(id));
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = () => {
    if (product) {
      addToCart(product);
      toast({
        title: "Added to Cart",
        description: `${product.name} has been added to your cart.`,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-32 pb-24 container px-4 mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <Skeleton className="aspect-square w-full bg-secondary" />
          <div className="space-y-6">
            <Skeleton className="h-10 w-3/4 bg-secondary" />
            <Skeleton className="h-6 w-1/4 bg-secondary" />
            <Skeleton className="h-32 w-full bg-secondary" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return <div className="pt-32 text-center">Product not found</div>;
  }

  return (
    <div className="min-h-screen pt-32 pb-24">
      <div className="container px-4 mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Image */}
          <div className="relative aspect-[4/5] bg-secondary overflow-hidden">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Details */}
          <div className="flex flex-col justify-center">
            <div className="mb-2 text-primary font-medium tracking-wider uppercase text-sm">
              {product.category}
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">{product.name}</h1>
            <div className="text-2xl font-medium text-foreground mb-8">₹{product.price}</div>
            
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              {product.description}
            </p>

            <Button 
              size="lg" 
              onClick={handleAddToCart}
              className="w-full md:w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-base uppercase tracking-widest px-12 py-8 rounded-none mb-10"
            >
              <ShoppingBag className="w-5 h-5 mr-3" />
              Add to Cart
            </Button>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 border-t border-border">
              <div className="flex items-center gap-3">
                <Star className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Top Rated</span>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Quality Guaranteed</span>
              </div>
              <div className="flex items-center gap-3">
                <Truck className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Fast Shipping</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
