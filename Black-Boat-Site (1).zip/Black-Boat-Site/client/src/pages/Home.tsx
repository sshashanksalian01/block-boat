import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="w-full h-screen overflow-hidden bg-black relative flex items-center justify-center overscroll-none touch-none">
      {/* Background Image - Black Panther */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/images/hero-panther.png" 
          alt="Black Panther" 
          className="w-full h-full object-cover opacity-60 grayscale scale-110 md:scale-100"
        />
        {/* Dramatic Shadow Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black" />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative z-10 text-center px-4 w-full max-w-lg mx-auto">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="flex flex-col items-center"
        >
          <h1 className="text-3xl sm:text-6xl md:text-8xl lg:text-[9rem] font-serif font-extralight text-white tracking-[0.1em] sm:tracking-[0.4em] leading-none mb-8 md:mb-12 drop-shadow-2xl uppercase whitespace-nowrap">
            BLACK BOAT
          </h1>
          <motion.div 
            initial={{ opacity: 0, width: 0 }}
            animate={{ opacity: 1, width: "auto" }}
            transition={{ delay: 1.2, duration: 1 }}
            className="overflow-hidden flex flex-col items-center w-full"
          >
            <p className="text-white/40 text-[8px] md:text-xs font-bold uppercase tracking-[0.6em] md:tracking-[1.5em] mb-3 md:mb-4">
              The Standard
            </p>
            <div className="h-px w-24 md:w-64 bg-gradient-to-r from-transparent via-white/20 to-transparent mb-3 md:mb-4" />
            <p className="text-white/80 text-[10px] md:text-sm font-medium uppercase tracking-[0.4em] md:tracking-[1.2em]">
              Built for Dominance
            </p>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Decorative accent line */}
      <div className="absolute bottom-8 md:bottom-12 left-1/2 -translate-x-1/2 w-px h-16 md:h-24 bg-gradient-to-b from-primary/50 to-transparent" />
    </div>
  );
}
