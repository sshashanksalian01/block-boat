import { Link } from "wouter";
import { type Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart-context";
import { useToast } from "@/hooks/use-toast";
import { ShoppingBag } from "lucide-react";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(product);
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
      duration: 2000,
    });
  };

  return (
    <Link href={`/products/${product.id}`} className="group block cursor-pointer">
      <div className="relative aspect-[3/4] overflow-hidden bg-secondary">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-90 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
      </div>
      
      <div className="mt-4 space-y-2">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-bold font-display tracking-wide text-foreground group-hover:text-primary transition-colors">
              {product.name}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">{product.category}</p>
          </div>
          <span className="text-lg font-medium text-primary">₹{product.price}</span>
        </div>
        
        <Button 
          onClick={handleAddToCart}
          className="w-full mt-4 bg-transparent border border-foreground/20 hover:bg-foreground hover:text-background text-foreground uppercase tracking-widest text-xs h-10 transition-all duration-300"
        >
          <ShoppingBag className="w-3 h-3 mr-2" />
          Add to Cart
        </Button>
      </div>
    </Link>
  );
}
