## Packages
framer-motion | Smooth page transitions and reveal animations
lucide-react | Beautiful icons for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
Cart state will be managed via a React Context (CartContext) for simplicity in this skeleton.
