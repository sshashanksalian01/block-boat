import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema, insertProductSchema } from "@shared/schema";
import { z } from "zod";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Simple admin check - you can customize this
  // For now, we'll allow access if authenticated via Replit Auth
  const isAdmin = (req: any, res: any, next: any) => {
    // Replit Auth provides user info in headers or req.user
    // For "owner only", we can check against a specific ID or just presence for now
    // as only the owner can typically log into a newly created Replit app unless shared.
    if (!req.headers["x-replit-user-id"]) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  app.get(api.products.list.path, async (req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID" });
    }
    const product = await storage.getProduct(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  });

  app.post(api.products.create.path, isAdmin, async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.patch(api.products.update.path, isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });
      const productData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, productData);
      res.json(product);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors });
      }
      res.status(404).json({ message: "Product not found" });
    }
  });

  app.delete(api.products.delete.path, isAdmin, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });
    await storage.deleteProduct(id);
    res.status(204).end();
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      res.status(201).json(order);
    } catch (e) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ message: e.errors });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // Seed data if empty
  const products = await storage.getProducts();
  if (products.length === 0) {
    console.log("Seeding products...");
    await storage.createProduct({
      name: "Charcoal Face Wash",
      description: "Deep cleansing face wash with activated charcoal to remove impurities and excess oil.",
      price: "499",
      image: "https://images.unsplash.com/photo-1608248597279-f99d160bfbc8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: "Face",
      featured: true,
    });
    await storage.createProduct({
      name: "Beard Growth Oil",
      description: "Premium blend of essential oils to promote beard growth and softness.",
      price: "799",
      image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: "Beard",
      featured: true,
    });
    await storage.createProduct({
      name: "Matte Hair Clay",
      description: "Strong hold hair clay with a matte finish for a natural look.",
      price: "649",
      image: "https://images.unsplash.com/photo-1597354984706-fac992d9306f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: "Hair",
      featured: false,
    });
    await storage.createProduct({
      name: "Sandalwood Body Wash",
      description: "Invigorating body wash with the rich scent of sandalwood.",
      price: "399",
      image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: "Body",
      featured: false,
    });
    await storage.createProduct({
      name: "Precision Razor Kit",
      description: "High-quality safety razor with replacement blades for a smooth shave.",
      price: "1299",
      image: "https://images.unsplash.com/photo-1599305090598-fe179d501227?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: "Shave",
      featured: true,
    });
    console.log("Seeding complete.");
  }

  return httpServer;
}
