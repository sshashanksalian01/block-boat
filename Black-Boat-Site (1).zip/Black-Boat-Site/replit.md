# Black Boat - Premium Men's Grooming

## Project Overview
A professional, premium e-commerce skeleton for a men's grooming brand.
Built with React, Express, and PostgreSQL.

## Features
- **Home**: Hero section, Featured Products, Brand Story.
- **Products**: Product catalog with categories and filtering.
- **Product Detail**: Detailed view with images and description.
- **Cart**: Local storage based cart management.
- **Checkout**: Order submission form.
- **Admin**: (Future) Product management.

## Tech Stack
- Frontend: React, Tailwind CSS, Shadcn UI, Wouter, Framer Motion.
- Backend: Node.js, Express.
- Database: PostgreSQL with Drizzle ORM.
- State Management: React Context (Cart) + TanStack Query.

## Design System
- **Theme**: Dark, masculine, premium.
- **Colors**: Black, Gold/White accents, Dark Gray backgrounds.
- **Typography**: Sans-serif (Inter) + Display fonts.

## Setup
1. `npm install`
2. `npm run db:push`
3. `npm run dev`
